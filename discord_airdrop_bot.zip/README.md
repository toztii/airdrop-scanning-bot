# Discord Airdrop Bot

### Funkcje:
- Powiadamia o nowych airdropach z airdrops.io i airdropsalert.com
- Pokazuje ceny BTC, ETH, SOL w statusie bota (co 10s)
- Śledzi tweety insiderów (whale_alert, cryptoleaks, lookonchain)

## Uruchomienie:
1. Uzupełnij `.env`
2. Zainstaluj zależności:
```bash
pip install -r requirements.txt
```
3. Odpal bota:
```bash
python main.py
```
